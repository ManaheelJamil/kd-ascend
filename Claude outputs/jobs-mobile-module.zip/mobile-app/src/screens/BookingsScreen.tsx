import React, { useEffect, useMemo, useState } from 'react';
import { ActivityIndicator, FlatList, Pressable, StyleSheet, View } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Text from '../components/AppText';
import BottomNav, { navigateTab } from '../components/BottomNav';
import { IconNavBookings } from '../components/AccountIcons';
import { CardButtons, DateTimeLine, StatusBadge } from '../components/JobParts';
import { IconBuilding, IconDollarCircle } from '../components/JobIcons';
import { useCancelFlow, useMyBookings } from '../hooks/useJobs';
import { useAuth } from '../context/AuthContext';
import {
  bookingState,
  eventStartMs,
  expectedEarnings,
  formatMoney,
  isUpcoming,
  rateLabel,
  type Booking,
} from '../services/jobsService';
import { colors, fonts, layout } from '../theme';
import type { ScreenProps } from '../navigation/types';

type TabKey = 'upcoming' | 'past';

function money(n: number | null, fallback: string) {
  if (n == null) return fallback;
  return n % 1 === 0 ? `$${n}` : formatMoney(n);
}

/** My Bookings (Figma 196:1624 Upcoming, 196:1765 Past). */
export default function BookingsScreen({ navigation, route }: ScreenProps<'Bookings'>) {
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const { bookings, loading, error } = useMyBookings(user?.uid);
  const [tab, setTab] = useState<TabKey>(route.params?.tab ?? 'upcoming');
  const cancel = useCancelFlow();

  useEffect(() => {
    if (route.params?.tab) setTab(route.params.tab);
  }, [route.params?.tab]);

  const { upcoming, past } = useMemo(() => {
    const now = Date.now();
    const up = bookings.filter((b) => isUpcoming(b, now));
    const pa = bookings.filter((b) => !isUpcoming(b, now));
    const start = (b: Booking) => eventStartMs(b.job) ?? 0;
    up.sort((a, b) => start(a) - start(b)); // next shift first
    pa.sort((a, b) => start(b) - start(a)); // most recent first
    return { upcoming: up, past: pa };
  }, [bookings]);

  const list = tab === 'upcoming' ? upcoming : past;

  return (
    <View style={styles.root}>
      <StatusBar style="dark" />
      <View style={{ paddingTop: insets.top + 12, paddingHorizontal: layout.gutter }}>
        <Text style={styles.title}>My Bookings</Text>
        <View style={styles.tabs} accessibilityRole="tablist">
          {(['upcoming', 'past'] as TabKey[]).map((k) => {
            const on = tab === k;
            const n = k === 'upcoming' ? upcoming.length : past.length;
            return (
              <Pressable
                key={k}
                onPress={() => setTab(k)}
                style={[styles.tab, on && styles.tabOn]}
                accessibilityRole="tab"
                accessibilityState={{ selected: on }}
              >
                <Text style={[styles.tabText, on && styles.tabTextOn]}>
                  {k === 'upcoming' ? 'Upcoming' : 'Past'} ({n})
                </Text>
              </Pressable>
            );
          })}
        </View>
      </View>

      <FlatList
        data={list}
        keyExtractor={(b) => b.app.id + b.job.id}
        contentContainerStyle={styles.content}
        ItemSeparatorComponent={() => <View style={{ height: 20 }} />}
        ListEmptyComponent={
          loading ? (
            <ActivityIndicator color={colors.main} style={{ marginTop: 60 }} />
          ) : (
            <View style={styles.empty}>
              <View style={styles.emptyIcon}>
                <IconNavBookings size={40} color={colors.grey} />
              </View>
              <Text style={styles.emptyTitle}>
                {error ? 'Couldn’t load bookings' : tab === 'upcoming' ? 'No upcoming bookings' : 'No past bookings'}
              </Text>
              <Text style={styles.emptyText}>
                {error ?? (tab === 'upcoming' ? 'Jobs you apply for will show up here.' : 'Finished and cancelled bookings show up here.')}
              </Text>
              {tab === 'upcoming' && !error ? (
                <Pressable onPress={() => navigateTab(navigation, 'home')} hitSlop={8} accessibilityRole="button">
                  <Text style={styles.link}>Browse jobs</Text>
                </Pressable>
              ) : null}
            </View>
          )
        }
        renderItem={({ item }) => {
          const state = bookingState(item);
          const earn = expectedEarnings(item.job);
          const canCancel = state === 'pending' || state === 'confirmed';
          return (
            <View style={styles.card}>
              <View style={styles.cardTop}>
                <View style={{ flex: 1 }}>
                  <Text style={styles.role} numberOfLines={1}>
                    {item.job.title}
                  </Text>
                  <View style={styles.corpRow}>
                    <IconBuilding />
                    <Text style={styles.corp} numberOfLines={1}>
                      {item.job.corporateName}
                    </Text>
                  </View>
                </View>
                <StatusBadge state={state} />
              </View>
              <View style={styles.rule} />
              <DateTimeLine job={item.job} />
              <View style={styles.earnRow}>
                <IconDollarCircle />
                <Text style={styles.earnLabel}>Expected Earning</Text>
                <Text style={styles.earn}>{money(earn, rateLabel(item.job.salary).amount)}</Text>
              </View>
              <CardButtons
                onDetail={() => navigation.navigate('BookingDetail', { jobId: item.job.id })}
                actionLabel={canCancel ? 'Cancel Booking' : undefined}
                onAction={() => cancel.start(item)}
              />
            </View>
          );
        }}
      />

      <BottomNav active="bookings" onChange={(t) => navigateTab(navigation, t)} />
      {cancel.modal}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.white },
  title: { fontFamily: fonts.semibold, fontSize: 24, lineHeight: 32, color: colors.text, textAlign: 'center' },
  tabs: { flexDirection: 'row', gap: 16, marginTop: 20, marginBottom: 6 },
  tab: { flex: 1, height: 46, borderRadius: 10, backgroundColor: colors.greyBg, alignItems: 'center', justifyContent: 'center' },
  tabOn: { backgroundColor: colors.dark },
  tabText: { fontFamily: fonts.regular, fontSize: 15, color: colors.grey },
  tabTextOn: { color: colors.white, fontFamily: fonts.medium },
  content: { paddingHorizontal: layout.gutter, paddingTop: 14, paddingBottom: 24, flexGrow: 1 },
  card: { backgroundColor: colors.greyBg, borderRadius: 20, padding: 20 },
  cardTop: { flexDirection: 'row', alignItems: 'flex-start', gap: 10 },
  role: { fontFamily: fonts.semibold, fontSize: 16, lineHeight: 22, color: colors.text },
  corpRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 4 },
  corp: { flex: 1, fontFamily: fonts.regular, fontSize: 12, color: colors.grey },
  rule: { height: 1, backgroundColor: colors.stroke, marginVertical: 12 },
  earnRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 10 },
  earnLabel: { flex: 1, fontFamily: fonts.regular, fontSize: 13, color: colors.grey },
  earn: { fontFamily: fonts.semibold, fontSize: 14, color: colors.text },
  empty: { alignItems: 'center', paddingVertical: 70, gap: 8 },
  emptyIcon: {
    width: 72,
    height: 72,
    borderRadius: 36,
    backgroundColor: colors.greyBg,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 6,
  },
  emptyTitle: { fontFamily: fonts.semibold, fontSize: 16, color: colors.text },
  emptyText: { fontFamily: fonts.regular, fontSize: 14, color: colors.grey, textAlign: 'center', maxWidth: 280 },
  link: { fontFamily: fonts.semibold, fontSize: 14, color: colors.main, textDecorationLine: 'underline', marginTop: 6 },
});
