import React, { useMemo, useState } from 'react';
import { ActivityIndicator, Alert, FlatList, Image, Pressable, StyleSheet, View } from 'react-native';
import Text from '../components/AppText';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import BottomNav, { navigateTab } from '../components/BottomNav';
import { IconNavBookings } from '../components/AccountIcons';
import { IconBellFilled, IconFilter, IconSearch } from '../components/JobIcons';
import { JobCard } from '../components/JobParts';
import JobFilterSheet, { DEFAULT_FILTERS, activeFilterCount, type JobFilters } from '../components/JobFilterSheet';
import { applyState, distinct, filterJobs, useApplyFlow, useMyBookings, useOpenJobs } from '../hooks/useJobs';
import { useAuth } from '../context/AuthContext';
import { images } from '../assets';
import { initials } from '../utils/format';
import { colors, fonts, layout } from '../theme';
import type { ScreenProps } from '../navigation/types';

/**
 * Home (Figma "Verified" 193:550): greeting, "Available Jobs" with search and filters,
 * live list of open jobs, Apply → Confirm Your Booking → Booking Submitted.
 */
export default function HomeScreen({ navigation }: ScreenProps<'Home'>) {
  const insets = useSafeAreaInsets();
  const { profile, user } = useAuth();
  const uid = user?.uid;
  const name = profile?.profile?.fullName || user?.email?.split('@')[0] || '';

  const { jobs, loading, error } = useOpenJobs(uid);
  const { bookings } = useMyBookings(uid);
  const [filters, setFilters] = useState<JobFilters>(DEFAULT_FILTERS);
  const [filterOpen, setFilterOpen] = useState(false);
  const apply = useApplyFlow(bookings, () => undefined);

  const shown = useMemo(() => filterJobs(jobs, { filters, bookings }), [jobs, filters, bookings]);
  const filterCount = activeFilterCount(filters);

  const header = (
    <View>
      <View style={styles.greetingRow}>
        <View>
          <View style={styles.avatar}>
            <Text style={styles.avatarText}>{initials(name)}</Text>
          </View>
          <Image source={images.illusVerifiedBadge} style={styles.verified} accessibilityLabel="Verified" />
        </View>
        <Text style={styles.hello} numberOfLines={1}>
          Hey, {name}
        </Text>
        <Pressable
          onPress={() => Alert.alert('Coming soon', 'Notifications will be available in a future update.')}
          style={({ pressed }) => [styles.bell, pressed && { opacity: 0.7 }]}
          accessibilityRole="button"
          accessibilityLabel="Notifications"
        >
          <IconBellFilled />
        </Pressable>
      </View>

      <View style={styles.titleRow}>
        <Text style={styles.heading}>
          Available <Text style={styles.headingBold}>Jobs</Text>
        </Text>
        <Pressable
          onPress={() => navigation.navigate('JobSearch')}
          style={({ pressed }) => [styles.roundBtn, pressed && { opacity: 0.7 }]}
          accessibilityRole="button"
          accessibilityLabel="Search jobs"
        >
          <IconSearch />
        </Pressable>
        <Pressable
          onPress={() => setFilterOpen(true)}
          style={({ pressed }) => [styles.roundBtn, styles.filterBtn, pressed && { opacity: 0.8 }]}
          accessibilityRole="button"
          accessibilityLabel={filterCount ? `Filters, ${filterCount} on` : 'Filters'}
        >
          <IconFilter />
          {filterCount ? (
            <View style={styles.filterCount}>
              <Text style={styles.filterCountText}>{filterCount}</Text>
            </View>
          ) : null}
        </Pressable>
      </View>
    </View>
  );

  const empty = loading ? (
    <View style={styles.empty}>
      <ActivityIndicator color={colors.main} />
    </View>
  ) : (
    <View style={styles.empty}>
      <View style={styles.emptyIcon}>
        <IconNavBookings size={40} color={colors.grey} />
      </View>
      <Text style={styles.emptyTitle}>{error ? 'Couldn’t load jobs' : filterCount ? 'No matching jobs' : 'No jobs yet'}</Text>
      <Text style={styles.emptyText}>
        {error ??
          (filterCount
            ? 'Try changing or clearing your filters.'
            : 'New jobs will show up here as soon as they’re available.')}
      </Text>
      {filterCount && !error ? (
        <Pressable onPress={() => setFilters(DEFAULT_FILTERS)} hitSlop={8} accessibilityRole="button">
          <Text style={styles.clear}>Clear filters</Text>
        </Pressable>
      ) : null}
    </View>
  );

  return (
    <View style={styles.root}>
      <StatusBar style="dark" />
      <FlatList
        data={shown}
        keyExtractor={(j) => j.id}
        contentContainerStyle={[styles.content, { paddingTop: insets.top + 12 }]}
        ListHeaderComponent={header}
        ListEmptyComponent={empty}
        ItemSeparatorComponent={() => <View style={{ height: 20 }} />}
        renderItem={({ item }) => {
          const st = applyState(item, bookings);
          return (
            <JobCard
              job={item}
              onDetail={() => navigation.navigate('JobDetail', { jobId: item.id })}
              actionLabel={st.label}
              actionDisabled={st.disabled}
              onAction={() => apply.start(item)}
            />
          );
        }}
      />

      <BottomNav active="home" onChange={(t) => navigateTab(navigation, t)} />

      <JobFilterSheet
        visible={filterOpen}
        value={filters}
        companies={distinct(jobs.map((j) => j.corporateName))}
        roles={distinct(jobs.map((j) => j.title))}
        onApply={(f) => {
          setFilters(f);
          setFilterOpen(false);
        }}
        onClose={() => setFilterOpen(false)}
      />
      {apply.modals}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.white },
  content: { paddingHorizontal: layout.gutter, paddingBottom: 24, flexGrow: 1 },
  greetingRow: { flexDirection: 'row', alignItems: 'center', gap: 12, minHeight: 50 },
  avatar: {
    width: 46,
    height: 46,
    borderRadius: 23,
    backgroundColor: colors.main,
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarText: { fontFamily: fonts.semibold, fontSize: 16, color: colors.white },
  verified: { position: 'absolute', right: -4, top: -4, width: 20, height: 20 },
  hello: { flex: 1, fontFamily: fonts.semibold, fontSize: 16, lineHeight: 25, color: colors.text },
  bell: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: colors.greyBg,
    alignItems: 'center',
    justifyContent: 'center',
  },
  titleRow: { flexDirection: 'row', alignItems: 'center', gap: 12, marginTop: 18, marginBottom: 20 },
  heading: { flex: 1, fontFamily: fonts.regular, fontSize: 28, lineHeight: 36, color: colors.text },
  headingBold: { fontFamily: fonts.semibold },
  roundBtn: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: colors.greyBg,
    alignItems: 'center',
    justifyContent: 'center',
  },
  filterBtn: { backgroundColor: colors.main },
  filterCount: {
    position: 'absolute',
    top: -2,
    right: -2,
    minWidth: 18,
    height: 18,
    borderRadius: 9,
    backgroundColor: colors.dark,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 4,
  },
  filterCountText: { fontFamily: fonts.semibold, fontSize: 11, color: colors.white },
  empty: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingVertical: 80, gap: 8 },
  emptyIcon: {
    width: 72,
    height: 72,
    borderRadius: 36,
    backgroundColor: colors.greyBg,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 6,
  },
  emptyTitle: { fontFamily: fonts.semibold, fontSize: 16, lineHeight: 25, color: colors.text },
  emptyText: { fontFamily: fonts.regular, fontSize: 14, lineHeight: 20, color: colors.grey, textAlign: 'center', maxWidth: 280 },
  clear: { fontFamily: fonts.semibold, fontSize: 14, color: colors.main, textDecorationLine: 'underline', marginTop: 6 },
});
