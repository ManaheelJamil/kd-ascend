import React, { useEffect, useState } from 'react';
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, View } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Text from '../components/AppText';
import { navigateTab } from '../components/BottomNav';
import {
  AboutJob,
  CancellationPolicy,
  CorporateLogo,
  EventLocation,
  InfoTiles,
  Requirements,
  ScreenHeader,
  SlotsRow,
} from '../components/JobParts';
import { IconArrowRightSmall, IconCalendarSmall, IconClock, IconDollar, IconPin } from '../components/JobIcons';
import { applyState, useApplyFlow, useMyBookings } from '../hooks/useJobs';
import { useAuth } from '../context/AuthContext';
import {
  expectedEarnings,
  formatMoney,
  rateLabel,
  shortDate,
  subscribeJob,
  timeLabel,
  type Job,
} from '../services/jobsService';
import { colors, fonts, layout } from '../theme';
import type { ScreenProps } from '../navigation/types';

/** Job Detail (Figma 194:944) with Apply For This Job → Confirm → Booking Submitted. */
export default function JobDetailScreen({ navigation, route }: ScreenProps<'JobDetail'>) {
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const { jobId } = route.params;
  const [job, setJob] = useState<Job | null | undefined>(undefined);
  const { bookings } = useMyBookings(user?.uid);
  const apply = useApplyFlow(bookings, () => navigateTab(navigation, 'home'));

  useEffect(() => subscribeJob(jobId, setJob, () => setJob(null)), [jobId]);

  if (job === undefined) {
    return (
      <View style={[styles.root, styles.center]}>
        <ActivityIndicator color={colors.main} />
      </View>
    );
  }
  if (job === null) {
    return (
      <View style={[styles.root, { paddingTop: insets.top + 8 }]}>
        <ScreenHeader title="Job Detail" onBack={() => navigation.goBack()} />
        <View style={styles.center}>
          <Text style={styles.goneTitle}>This job isn’t available</Text>
          <Text style={styles.goneText}>It may have been removed by the organiser.</Text>
        </View>
      </View>
    );
  }

  const rate = rateLabel(job.salary);
  const earn = expectedEarnings(job);
  const mine = bookings.find((b) => b.job.id === job.id);
  const st = job.status === 'open' ? applyState(job, bookings) : { label: 'Not Available', disabled: true };

  return (
    <View style={styles.root}>
      <StatusBar style="dark" />
      <View style={{ paddingTop: insets.top + 8 }}>
        <ScreenHeader title="Job Detail" onBack={() => navigation.goBack()} />
      </View>
      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.corpCard}>
          <CorporateLogo name={job.corporateName} size={50} />
          <View style={{ flex: 1 }}>
            <Text style={styles.corpName}>{job.corporateName}</Text>
            <View style={styles.addrRow}>
              <IconPin size={14} />
              <Text style={styles.addr} numberOfLines={2}>
                {job.location || '—'}
              </Text>
            </View>
          </View>
        </View>

        <Text style={styles.role}>{job.title}</Text>
        <InfoTiles
          items={[
            { icon: <IconCalendarSmall size={24} color={colors.main} />, label: 'Event Date', value: shortDate(job.eventDate) },
            { icon: <IconClock />, label: 'Event Time', value: timeLabel(job.eventTime) },
            { icon: <IconDollar />, label: 'Rate', value: `${rate.amount}${rate.unit ? '/hour' : ''}` },
          ]}
        />
        <View style={{ marginTop: 14 }}>
          <SlotsRow job={job} chips />
        </View>

        <View style={styles.section}>
          <AboutJob description={job.description} />
        </View>
        <View style={styles.section}>
          <Requirements items={job.requirements} />
        </View>
        <View style={styles.section}>
          <CancellationPolicy />
        </View>
        <View style={styles.section}>
          <EventLocation address={job.location} />
        </View>
      </ScrollView>

      <View style={[styles.bottom, { paddingBottom: Math.max(insets.bottom, 12) + 6 }]}>
        <View style={{ flex: 1 }}>
          <Text style={styles.earnLabel}>Expected Earnings</Text>
          <Text style={styles.earn}>{earn != null ? formatMoney(earn) : rate.amount}</Text>
        </View>
        {mine && (mine.app.status === 'pending' || mine.app.status === 'approved') ? (
          <Pressable
            onPress={() => navigation.navigate('BookingDetail', { jobId: job.id })}
            style={({ pressed }) => [styles.applyBtn, pressed && { opacity: 0.85 }]}
            accessibilityRole="button"
          >
            <Text style={styles.applyText}>View Booking</Text>
            <IconArrowRightSmall />
          </Pressable>
        ) : (
          <Pressable
            onPress={() => apply.start(job)}
            disabled={st.disabled}
            style={({ pressed }) => [
              styles.applyBtn,
              st.disabled && { backgroundColor: colors.stroke },
              pressed && !st.disabled && { opacity: 0.85 },
            ]}
            accessibilityRole="button"
            accessibilityState={{ disabled: st.disabled }}
          >
            <Text style={[styles.applyText, st.disabled && { color: colors.grey }]}>
              {st.disabled ? st.label : 'Apply For This Job'}
            </Text>
            {st.disabled ? null : <IconArrowRightSmall />}
          </Pressable>
        )}
      </View>
      {apply.modals}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.white },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 24, gap: 6 },
  goneTitle: { fontFamily: fonts.semibold, fontSize: 18, color: colors.text },
  goneText: { fontFamily: fonts.regular, fontSize: 14, color: colors.grey, textAlign: 'center' },
  content: { paddingHorizontal: layout.gutter, paddingTop: 16, paddingBottom: 30 },
  corpCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    backgroundColor: colors.greyBg,
    borderRadius: 18,
    padding: 18,
  },
  corpName: { fontFamily: fonts.semibold, fontSize: 18, lineHeight: 24, color: colors.text },
  addrRow: { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 4 },
  addr: { flex: 1, fontFamily: fonts.regular, fontSize: 12, lineHeight: 16, color: colors.grey },
  role: { fontFamily: fonts.semibold, fontSize: 20, lineHeight: 28, color: colors.text, marginTop: 22, marginBottom: 12 },
  section: { marginTop: 24 },
  bottom: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingHorizontal: layout.gutter,
    paddingTop: 14,
    backgroundColor: colors.white,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    shadowColor: '#000',
    shadowOpacity: 0.08,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: -2 },
    elevation: 10,
  },
  earnLabel: { fontFamily: fonts.regular, fontSize: 12, color: colors.grey },
  earn: { fontFamily: fonts.bold, fontSize: 24, lineHeight: 32, color: colors.text },
  applyBtn: {
    height: 50,
    borderRadius: 12,
    backgroundColor: colors.main,
    paddingHorizontal: 20,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    minWidth: 190,
  },
  applyText: { fontFamily: fonts.medium, fontSize: 16, color: colors.white },
});
