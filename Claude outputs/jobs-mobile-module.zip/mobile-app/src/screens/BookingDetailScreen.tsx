import React, { useEffect, useMemo, useState } from 'react';
import { ActivityIndicator, Pressable, ScrollView, Share, StyleSheet, View } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Text from '../components/AppText';
import {
  AboutJob,
  CancellationPolicy,
  CorporateLogo,
  EventLocation,
  InfoTiles,
  InfoTilesRow,
  PaymentMethodRow,
  Requirements,
  ScreenHeader,
  SectionTitle,
  StatusBadge,
} from '../components/JobParts';
import { IconCalendarSmall, IconClock, IconCopy, IconDollar } from '../components/JobIcons';
import { useCancelFlow, useMyBookings } from '../hooks/useJobs';
import { useAuth } from '../context/AuthContext';
import {
  bookingCode,
  bookingState,
  expectedEarnings,
  formatMoney,
  rateLabel,
  shortDate,
  subscribeMyPayments,
  timeLabel,
  type PaymentTransaction,
} from '../services/jobsService';
import { colors, fonts, layout } from '../theme';
import type { ScreenProps } from '../navigation/types';

function money(n: number) {
  return n % 1 === 0 ? `$${n}` : formatMoney(n);
}

/**
 * Booking detail: Figma "confirmed job" (196:1989) with Cancel Booking (308:491),
 * and "Completed job" (196:2272) with the final earnings once the admin has paid out.
 */
export default function BookingDetailScreen({ navigation, route }: ScreenProps<'BookingDetail'>) {
  const insets = useSafeAreaInsets();
  const { user, profile } = useAuth();
  const { jobId } = route.params;
  const { bookings, loading } = useMyBookings(user?.uid);
  const [payments, setPayments] = useState<PaymentTransaction[]>([]);
  const cancel = useCancelFlow();

  useEffect(() => {
    if (!user?.uid) return;
    return subscribeMyPayments(user.uid, setPayments, () => undefined);
  }, [user?.uid]);

  const booking = useMemo(() => bookings.find((b) => b.job.id === jobId) ?? null, [bookings, jobId]);
  const payout = payments.find((p) => p.jobId === jobId && p.type === 'payout' && p.status !== 'failed');
  const penalty = payments.find((p) => p.jobId === jobId && p.type === 'penalty' && p.status !== 'failed');

  if (!booking) {
    return (
      <View style={[styles.root, { paddingTop: insets.top + 8 }]}>
        <ScreenHeader title="Booking" onBack={() => navigation.goBack()} />
        <View style={styles.center}>
          {loading ? (
            <ActivityIndicator color={colors.main} />
          ) : (
            <>
              <Text style={styles.goneTitle}>Booking not found</Text>
              <Text style={styles.goneText}>This booking may have been removed.</Text>
            </>
          )}
        </View>
      </View>
    );
  }

  const { job } = booking;
  const state = bookingState(booking);
  const code = bookingCode(booking);
  const rate = rateLabel(job.salary);
  const rateText = `${rate.amount}${rate.unit ? '/hour' : ''}`;
  const earn = expectedEarnings(job);
  const canCancel = state === 'pending' || state === 'confirmed';
  const completed = state === 'completed';
  const method =
    profile?.payout?.method === 'bank' ? 'Bank Transfer' : profile?.payout?.method === 'paynow' ? 'PayNow' : payout?.method || '—';

  const share = () => {
    void Share.share({ message: `Booking ID: ${code}` });
  };

  return (
    <View style={styles.root}>
      <StatusBar style="dark" />
      <View style={{ paddingTop: insets.top + 8 }}>
        <ScreenHeader
          title={`Booking ID: ${code}`}
          onBack={() => navigation.goBack()}
          right={
            <Pressable onPress={share} hitSlop={10} accessibilityRole="button" accessibilityLabel="Copy booking ID">
              <IconCopy />
            </Pressable>
          }
        />
      </View>

      <ScrollView contentContainerStyle={[styles.content, { paddingBottom: insets.bottom + 24 }]}>
        <View style={styles.corpCard}>
          <CorporateLogo name={job.corporateName} size={50} />
          <View style={{ flex: 1 }}>
            <Text style={styles.corpName} numberOfLines={1}>
              {job.corporateName}
            </Text>
            <Text style={styles.roleSmall} numberOfLines={1}>
              {job.title}
            </Text>
          </View>
          <StatusBadge state={state} />
        </View>

        {completed ? (
          <View style={styles.section}>
            <SectionTitle>Final Schedule &amp; Earnings</SectionTitle>
            <InfoTilesRow
              items={[
                { icon: <IconCalendarSmall size={24} color={colors.main} />, label: 'Date', value: shortDate(job.eventDate) },
                { icon: <IconClock />, label: 'Time', value: timeLabel(job.eventTime) },
                {
                  icon: <IconDollar />,
                  label: 'Earnings',
                  value: payout
                    ? `${money(payout.amount)} (${money(payout.hourlyRate)}/hour)${payout.status === 'completed' ? '' : ' · processing'}`
                    : earn != null
                      ? `${money(earn)} (${rateText}) · awaiting payout`
                      : rateText,
                },
                { icon: <IconDollar />, label: 'Bonus', value: money(payout?.bonus ?? 0) },
              ]}
            />
            {payout && payout.deduction > 0 ? (
              <Text style={styles.deduction}>Deduction: -{money(payout.deduction)}{payout.note ? ` · ${payout.note}` : ''}</Text>
            ) : null}
          </View>
        ) : (
          <View style={styles.section}>
            <SectionTitle>Schedule &amp; Earnings</SectionTitle>
            <InfoTiles
              items={[
                { icon: <IconCalendarSmall size={24} color={colors.main} />, label: 'Date', value: shortDate(job.eventDate) },
                { icon: <IconClock />, label: 'Time', value: timeLabel(job.eventTime) },
                { icon: <IconDollar />, label: 'Earnings', value: earn != null ? `${money(earn)} (${rateText})` : rateText },
              ]}
            />
          </View>
        )}

        {state === 'pending' ? (
          <Text style={styles.info}>Waiting for the admin to approve your booking. You’ll see “Confirmed” here once approved.</Text>
        ) : state === 'rejected' ? (
          <Text style={styles.info}>Your booking was unsuccessful. Please make another booking!</Text>
        ) : state === 'job_cancelled' ? (
          <Text style={[styles.info, { color: colors.error }]}>The organiser cancelled this job.</Text>
        ) : state === 'cancelled' ? (
          <Text style={[styles.info, { color: colors.error }]}>
            You cancelled this booking.
            {penalty ? ` A late-cancellation penalty of ${money(penalty.amount)} applies.` : ''}
          </Text>
        ) : null}

        <View style={styles.section}>
          <AboutJob description={job.description} />
        </View>
        <View style={styles.section}>
          <Requirements items={job.requirements} />
        </View>
        {canCancel ? (
          <View style={styles.section}>
            <CancellationPolicy />
          </View>
        ) : null}
        <View style={styles.section}>
          <EventLocation address={job.location} />
        </View>
        <View style={{ marginTop: 16 }}>
          <PaymentMethodRow method={method} icon={<IconDollar />} />
        </View>

        {canCancel ? (
          <Pressable
            onPress={() => cancel.start(booking)}
            style={({ pressed }) => [styles.cancelBtn, pressed && { opacity: 0.85 }]}
            accessibilityRole="button"
          >
            <Text style={styles.cancelText}>Cancel Booking</Text>
          </Pressable>
        ) : null}
      </ScrollView>
      {cancel.modal}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.white },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 24, gap: 6 },
  goneTitle: { fontFamily: fonts.semibold, fontSize: 18, color: colors.text },
  goneText: { fontFamily: fonts.regular, fontSize: 14, color: colors.grey, textAlign: 'center' },
  content: { paddingHorizontal: layout.gutter, paddingTop: 16 },
  corpCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    backgroundColor: colors.greyBg,
    borderRadius: 18,
    padding: 18,
  },
  corpName: { fontFamily: fonts.semibold, fontSize: 16, lineHeight: 22, color: colors.text },
  roleSmall: { fontFamily: fonts.regular, fontSize: 14, color: colors.grey, marginTop: 2 },
  section: { marginTop: 24 },
  info: { fontFamily: fonts.regular, fontSize: 13, lineHeight: 19, color: colors.grey, marginTop: 14 },
  deduction: { fontFamily: fonts.regular, fontSize: 12, color: colors.error, marginTop: 10 },
  cancelBtn: {
    marginTop: 24,
    height: 52,
    borderRadius: 12,
    backgroundColor: colors.error,
    alignItems: 'center',
    justifyContent: 'center',
  },
  cancelText: { fontFamily: fonts.medium, fontSize: 16, color: colors.white },
});
