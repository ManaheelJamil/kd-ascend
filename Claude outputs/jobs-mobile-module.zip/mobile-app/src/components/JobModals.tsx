/**
 * Popups of the Jobs module: Confirm Your Booking, Booking Submitted, Cancel Booking
 * (Figma "Confirm Bookingl", "Booking Submitted", "Cancel job").
 */
import React from 'react';
import { ActivityIndicator, Pressable, StyleSheet, View } from 'react-native';
import Text from './AppText';
import AppModal from './AppModal';
import { colors, fonts } from '../theme';
import { CancellationPolicy } from './JobParts';
import {
  IconArrowRightSmall,
  IconCalendarSmall,
  IconClock,
  IconDollar,
  IllusCancelBooking,
  IllusSubmitted,
} from './JobIcons';
import { rateLabel, shortDate, timeLabel, type Job } from '../services/jobsService';

function ModalButton({
  title,
  onPress,
  tone,
  loading,
  disabled,
  right,
}: {
  title: string;
  onPress: () => void;
  tone: 'outline' | 'orange' | 'red';
  loading?: boolean;
  disabled?: boolean;
  right?: React.ReactNode;
}) {
  const inactive = loading || disabled;
  return (
    <Pressable
      onPress={onPress}
      disabled={inactive}
      accessibilityRole="button"
      accessibilityState={{ disabled: !!inactive, busy: !!loading }}
      style={({ pressed }) => [
        styles.btn,
        tone === 'outline' && styles.btnOutline,
        tone === 'orange' && { backgroundColor: colors.main },
        tone === 'red' && { backgroundColor: colors.error },
        pressed && !inactive && { opacity: 0.85 },
        disabled && !loading && { opacity: 0.5 },
      ]}
    >
      {loading ? (
        <ActivityIndicator color={tone === 'outline' ? colors.dark : colors.white} />
      ) : (
        <View style={styles.btnRow}>
          <Text style={[styles.btnText, tone === 'outline' && { color: colors.text }]}>{title}</Text>
          {right}
        </View>
      )}
    </Pressable>
  );
}

function JobSummary({ job, showRate = true }: { job: Job; showRate?: boolean }) {
  const rate = rateLabel(job.salary);
  return (
    <View style={styles.summary}>
      <Text style={styles.summaryCorp}>{job.corporateName}</Text>
      <Text style={styles.summaryRole}>{job.title}</Text>
      <View style={styles.summaryLine}>
        <IconClock size={18} />
        <Text style={styles.summaryText}>{timeLabel(job.eventTime)}</Text>
      </View>
      <View style={styles.summaryLine}>
        <IconCalendarSmall size={18} color={colors.main} />
        <Text style={styles.summaryText}>{shortDate(job.eventDate)}</Text>
      </View>
      {showRate ? (
        <View style={styles.summaryLine}>
          <IconDollar size={18} />
          <Text style={styles.summaryText}>
            {rate.amount}
            {rate.unit ? '/hour' : ''}
          </Text>
        </View>
      ) : null}
    </View>
  );
}

export function ConfirmBookingModal({
  job,
  visible,
  busy,
  onConfirm,
  onClose,
}: {
  job: Job | null;
  visible: boolean;
  busy: boolean;
  onConfirm: () => void;
  onClose: () => void;
}) {
  if (!job) return null;
  return (
    <AppModal visible={visible} onClose={busy ? undefined : onClose} cardStyle={styles.card}>
      <Text style={styles.titleLeft}>Confirm Your Booking</Text>
      <JobSummary job={job} />
      <View style={{ marginTop: 14 }}>
        <CancellationPolicy />
      </View>
      <Text style={styles.subject}>This booking is subject to Admin’s approval.</Text>
      <View style={styles.row}>
        <ModalButton title="Cancel" tone="outline" onPress={onClose} disabled={busy} />
        <ModalButton title="Confirm Booking" tone="orange" onPress={onConfirm} loading={busy} />
      </View>
    </AppModal>
  );
}

export function BookingSubmittedModal({ visible, onHome }: { visible: boolean; onHome: () => void }) {
  return (
    <AppModal visible={visible} onClose={onHome} cardStyle={[styles.card, { alignItems: 'center' }]}>
      <View style={{ marginTop: 10 }}>
        <IllusSubmitted />
      </View>
      <Text style={styles.titleCenter}>Booking Submitted</Text>
      <Text style={styles.bodyCenter}>
        Your booking has been submitted successfully. You will be notified latest 3 days before the event.
      </Text>
      <View style={styles.pending}>
        <View style={styles.pendingIcon}>
          <IconClock size={18} color={colors.white} />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={styles.pendingTitle}>Pending Approval</Text>
          <Text style={styles.pendingText}>Your request will be reviewed by Admin.</Text>
        </View>
      </View>
      <View style={{ width: '62%', marginTop: 18 }}>
        <ModalButton
          title="Go To Home"
          tone="orange"
          onPress={onHome}
          right={<IconArrowRightSmall size={16} />}
        />
      </View>
    </AppModal>
  );
}

export function CancelBookingModal({
  job,
  visible,
  late,
  busy,
  onConfirm,
  onClose,
}: {
  job: Job | null;
  visible: boolean;
  late: boolean;
  busy: boolean;
  onConfirm: () => void;
  onClose: () => void;
}) {
  if (!job) return null;
  return (
    <AppModal visible={visible} onClose={busy ? undefined : onClose} cardStyle={[styles.card, { alignItems: 'stretch' }]}>
      <View style={{ alignItems: 'center', marginTop: 8 }}>
        <IllusCancelBooking />
        <Text style={styles.titleCenter}>Cancel Booking</Text>
      </View>
      {late ? (
        <View style={{ marginTop: 12 }}>
          <CancellationPolicy late />
        </View>
      ) : null}
      <JobSummary job={job} showRate={false} />
      <Text style={styles.subject}>Are you sure you want to cancel?</Text>
      <View style={styles.row}>
        <ModalButton title="Go Back" tone="outline" onPress={onClose} disabled={busy} />
        <ModalButton title="Yes, Cancel" tone="red" onPress={onConfirm} loading={busy} />
      </View>
    </AppModal>
  );
}

const styles = StyleSheet.create({
  card: { paddingHorizontal: 20, paddingTop: 24, paddingBottom: 22 },
  titleLeft: { fontFamily: fonts.semibold, fontSize: 22, lineHeight: 30, color: colors.text, paddingRight: 44 },
  titleCenter: {
    fontFamily: fonts.semibold,
    fontSize: 24,
    lineHeight: 32,
    color: colors.text,
    textAlign: 'center',
    marginTop: 12,
  },
  bodyCenter: {
    fontFamily: fonts.regular,
    fontSize: 15,
    lineHeight: 21,
    color: colors.grey,
    textAlign: 'center',
    marginTop: 6,
  },
  summary: { backgroundColor: colors.greyBg, borderRadius: 14, padding: 16, marginTop: 18, gap: 2 },
  summaryCorp: { fontFamily: fonts.semibold, fontSize: 16, lineHeight: 22, color: colors.text },
  summaryRole: { fontFamily: fonts.regular, fontSize: 14, lineHeight: 20, color: colors.grey, marginBottom: 8 },
  summaryLine: { flexDirection: 'row', alignItems: 'center', gap: 10, marginTop: 8 },
  summaryText: { fontFamily: fonts.medium, fontSize: 13, color: colors.text },
  subject: {
    fontFamily: fonts.regular,
    fontSize: 13,
    lineHeight: 18,
    color: colors.grey,
    textAlign: 'center',
    marginTop: 14,
  },
  row: { flexDirection: 'row', gap: 14, marginTop: 18 },
  btn: { flex: 1, height: 48, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  btnOutline: { borderWidth: 1, borderColor: colors.text, backgroundColor: colors.white },
  btnRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  btnText: { fontFamily: fonts.medium, fontSize: 16, color: colors.white },
  pending: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    backgroundColor: 'rgba(255,130,65,0.09)',
    borderRadius: 10,
    padding: 12,
    alignSelf: 'stretch',
    marginTop: 16,
  },
  pendingIcon: {
    width: 30,
    height: 30,
    borderRadius: 15,
    backgroundColor: colors.main,
    alignItems: 'center',
    justifyContent: 'center',
  },
  pendingTitle: { fontFamily: fonts.semibold, fontSize: 14, color: colors.text },
  pendingText: { fontFamily: fonts.regular, fontSize: 12, color: colors.grey, marginTop: 2 },
});
