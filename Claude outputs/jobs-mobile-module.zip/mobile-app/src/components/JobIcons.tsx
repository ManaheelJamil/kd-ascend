/**
 * Icons for the Jobs module (Figma "Verified", "Job Detail", "Bookings" frames), drawn as SVG
 * so their colours follow the theme.
 */
import React from 'react';
import { Circle, G, Path, Rect, Svg } from 'react-native-svg';
import { colors } from '../theme';

type P = { size?: number; color?: string };

export function IconPin({ size = 14, color = colors.grey }: P) {
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <Path
        d="M12 21s-7-6.2-7-11.5A7 7 0 0 1 19 9.5C19 14.8 12 21 12 21Z"
        stroke={color}
        strokeWidth={1.8}
        strokeLinejoin="round"
      />
      <Circle cx={12} cy={9.5} r={2.5} stroke={color} strokeWidth={1.8} />
    </Svg>
  );
}

export function IconCalendarSmall({ size = 16, color = colors.grey }: P) {
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <Rect x={3} y={5} width={18} height={16} rx={3} stroke={color} strokeWidth={1.7} />
      <Path d="M3 10h18M8 3v4M16 3v4" stroke={color} strokeWidth={1.7} strokeLinecap="round" />
    </Svg>
  );
}

export function IconClock({ size = 24, color = colors.main }: P) {
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <Circle cx={12} cy={12} r={9} stroke={color} strokeWidth={1.7} />
      <Path d="M12 7v5l3 2" stroke={color} strokeWidth={1.7} strokeLinecap="round" strokeLinejoin="round" />
    </Svg>
  );
}

export function IconDollar({ size = 24, color = colors.main }: P) {
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <Path
        d="M12 2.5v19M16.5 6.5c-.8-1.3-2.5-2-4.5-2-2.6 0-4.5 1.3-4.5 3.4 0 4.9 9.4 2.4 9.4 7.5 0 2.1-2 3.6-4.9 3.6-2.1 0-3.9-.8-4.8-2.3"
        stroke={color}
        strokeWidth={1.8}
        strokeLinecap="round"
      />
    </Svg>
  );
}

export function IconDollarCircle({ size = 16, color = colors.grey }: P) {
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <Circle cx={12} cy={12} r={9} stroke={color} strokeWidth={1.6} />
      <Path
        d="M12 6.5v11M14.6 8.8c-.5-.7-1.4-1.1-2.6-1.1-1.5 0-2.6.7-2.6 1.9 0 2.8 5.4 1.4 5.4 4.3 0 1.2-1.1 2-2.8 2-1.2 0-2.2-.4-2.7-1.3"
        stroke={color}
        strokeWidth={1.5}
        strokeLinecap="round"
      />
    </Svg>
  );
}

export function IconUser({ size = 16, color = colors.text }: P) {
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <Circle cx={12} cy={8} r={4} stroke={color} strokeWidth={1.7} />
      <Path d="M4.5 20.5c1.2-3.6 4-5.5 7.5-5.5s6.3 1.9 7.5 5.5" stroke={color} strokeWidth={1.7} strokeLinecap="round" />
    </Svg>
  );
}

export function IconBuilding({ size = 14, color = colors.grey }: P) {
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <Path d="M4 21V5a2 2 0 0 1 2-2h7a2 2 0 0 1 2 2v16M15 9h3a2 2 0 0 1 2 2v10M2.5 21h19" stroke={color} strokeWidth={1.7} strokeLinecap="round" />
      <Path d="M8 7.5h3M8 11.5h3M8 15.5h3" stroke={color} strokeWidth={1.7} strokeLinecap="round" />
    </Svg>
  );
}

export function IconArrowUpRight({ size = 14, color = colors.main }: P) {
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <Path d="M6 18 18 6M8.5 6H18v9.5" stroke={color} strokeWidth={2.2} strokeLinecap="round" strokeLinejoin="round" />
    </Svg>
  );
}

export function IconArrowRightSmall({ size = 16, color = colors.white }: P) {
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <Path d="M4 12h15M13 6l6 6-6 6" stroke={color} strokeWidth={2.2} strokeLinecap="round" strokeLinejoin="round" />
    </Svg>
  );
}

export function IconSearch({ size = 24, color = colors.text }: P) {
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <Circle cx={11} cy={11} r={7} stroke={color} strokeWidth={2} />
      <Path d="m20 20-3.8-3.8" stroke={color} strokeWidth={2} strokeLinecap="round" />
    </Svg>
  );
}

/** Three lines getting shorter (Figma filter button). */
export function IconFilter({ size = 24, color = colors.white }: P) {
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <Path d="M3.5 6.5h17M6.5 12h11M9.5 17.5h5" stroke={color} strokeWidth={2} strokeLinecap="round" />
    </Svg>
  );
}

export function IconSort({ size = 20, color = colors.main }: P) {
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <Path d="M7 20V4M7 4 3.5 7.5M7 4l3.5 3.5M17 4v16M17 20l-3.5-3.5M17 20l3.5-3.5" stroke={color} strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" />
    </Svg>
  );
}

export function IconBellFilled({ size = 22, color = colors.text }: P) {
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <Path
        d="M12 2.5a6.5 6.5 0 0 0-6.5 6.5v3.6l-1.6 2.9A1 1 0 0 0 4.8 17h14.4a1 1 0 0 0 .9-1.5l-1.6-2.9V9A6.5 6.5 0 0 0 12 2.5Z"
        fill={color}
      />
      <Path d="M9.5 19a2.5 2.5 0 0 0 5 0h-5Z" fill={color} />
    </Svg>
  );
}

export function IconChevronLeft({ size = 18, color = colors.white }: P) {
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <Path d="m15 5-7 7 7 7" stroke={color} strokeWidth={2.6} strokeLinecap="round" strokeLinejoin="round" />
    </Svg>
  );
}

export function IconChevronDownSmall({ size = 18, color = colors.main }: P) {
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <Path d="m6 9 6 6 6-6" stroke={color} strokeWidth={2.2} strokeLinecap="round" strokeLinejoin="round" />
    </Svg>
  );
}

export function IconCheckCircle({ size = 18, color = colors.main }: P) {
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <Circle cx={12} cy={12} r={9} stroke={color} strokeWidth={1.7} />
      <Path d="m8 12.2 2.7 2.7L16 9.5" stroke={color} strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" />
    </Svg>
  );
}

export function IconWarning({ size = 22, color = colors.error }: P) {
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <Path d="M10.3 3.6a2 2 0 0 1 3.4 0l8.4 14.6a2 2 0 0 1-1.7 3H3.6a2 2 0 0 1-1.7-3L10.3 3.6Z" fill={color} />
      <Path d="M12 9v4.5" stroke={colors.white} strokeWidth={2} strokeLinecap="round" />
      <Circle cx={12} cy={17} r={1.2} fill={colors.white} />
    </Svg>
  );
}

export function IconNavigate({ size = 20, color = colors.main }: P) {
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <Path d="M21 3 3 10.5l7.5 3 3 7.5L21 3Z" stroke={color} strokeWidth={1.8} strokeLinejoin="round" />
    </Svg>
  );
}

export function IconCopy({ size = 22, color = colors.text }: P) {
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <Rect x={8} y={8} width={13} height={13} rx={3} stroke={color} strokeWidth={1.8} />
      <Path d="M16 8V6a3 3 0 0 0-3-3H6a3 3 0 0 0-3 3v7a3 3 0 0 0 3 3h2" stroke={color} strokeWidth={1.8} />
    </Svg>
  );
}

/** Green star-shaped badge with a tick (Figma "Booking Submitted"). */
export function IllusSubmitted({ size = 96 }: { size?: number }) {
  const pts: string[] = [];
  const n = 12;
  for (let i = 0; i < n * 2; i++) {
    const r = i % 2 === 0 ? 46 : 39;
    const a = (Math.PI * i) / n - Math.PI / 2;
    pts.push(`${50 + r * Math.cos(a)},${50 + r * Math.sin(a)}`);
  }
  return (
    <Svg width={size} height={size} viewBox="0 0 100 100">
      <Path d={`M${pts.join('L')}Z`} fill={colors.green} strokeLinejoin="round" stroke={colors.green} strokeWidth={4} />
      <Path d="m33 51 12 12 23-25" stroke={colors.white} strokeWidth={8} fill="none" strokeLinecap="round" strokeLinejoin="round" />
    </Svg>
  );
}

/** Red calendar with a cross (Figma "Cancel Booking"). */
export function IllusCancelBooking({ size = 76 }: { size?: number }) {
  return (
    <Svg width={size} height={size} viewBox="0 0 80 80">
      <Rect x={10} y={14} width={60} height={56} rx={9} fill={colors.error} />
      <Rect x={10} y={14} width={60} height={14} rx={7} fill="#E02424" />
      <Rect x={22} y={6} width={7} height={16} rx={3.5} fill={colors.error} />
      <Rect x={51} y={6} width={7} height={16} rx={3.5} fill={colors.error} />
      <Path d="m31 38 18 18M49 38 31 56" stroke={colors.white} strokeWidth={6} strokeLinecap="round" />
    </Svg>
  );
}

/** Simple street-map illustration behind the event location card. */
export function MapIllustration({ width, height }: { width: number; height: number }) {
  return (
    <Svg width={width} height={height} viewBox="0 0 400 200" preserveAspectRatio="xMidYMid slice">
      <Rect width={400} height={200} fill="#ECE7E2" />
      <Path d="M0 0h90l-30 70H0Z" fill="#F4CBD3" />
      <Path d="M360 40 400 20v70l-50 10Z" fill="#9AD77A" />
      <G stroke="#FFFFFF" strokeWidth={9} fill="none" strokeLinecap="round">
        <Path d="M40 200 120 110l70 40 90-40 120 30" />
        <Path d="M150 0 170 80l-20 120" />
        <Path d="M260 0l-10 110 30 90" />
        <Path d="M190 150l60 30M300 120l30 60" />
      </G>
      <G stroke="#F5C76A" strokeWidth={12} fill="none" strokeLinecap="round">
        <Path d="M0 60c60 10 100 10 140 30s120 10 160-10 60-30 100-20" />
        <Path d="M110 0c10 50 40 90 30 130s-10 50 0 70" />
      </G>
      <Path d="M0 170c50-20 90 0 140 10" stroke="#9CC8F0" strokeWidth={7} fill="none" />
      <Circle cx={270} cy={130} r={10} fill="#E9474B" />
    </Svg>
  );
}
