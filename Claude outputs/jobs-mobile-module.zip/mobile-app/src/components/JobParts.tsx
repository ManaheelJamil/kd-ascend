/**
 * Building blocks shared by the Jobs screens (Figma "Verified", "Search", "Job Detail",
 * "Bookings", "confirmed job", "Completed job").
 */
import React from 'react';
import { Linking, Pressable, StyleSheet, View, useWindowDimensions, type StyleProp, type ViewStyle } from 'react-native';
import Text from './AppText';
import { colors, fonts } from '../theme';
import {
  IconArrowUpRight,
  IconCalendarSmall,
  IconCheckCircle,
  IconChevronLeft,
  IconNavigate,
  IconPin,
  IconUser,
  IconWarning,
  MapIllustration,
} from './JobIcons';
import {
  LATE_CANCEL_PENALTY,
  genders,
  rateLabel,
  shortDate,
  slotsLeft,
  timeLabel,
  type BookingState,
  type Job,
} from '../services/jobsService';

/* ------------------------------------------------------------------ small pieces */

/** Dark rounded back button (Figma "Job Detail" header). */
export function DarkBackButton({ onPress }: { onPress: () => void }) {
  return (
    <Pressable
      onPress={onPress}
      hitSlop={10}
      accessibilityRole="button"
      accessibilityLabel="Go back"
      style={({ pressed }) => [styles.back, pressed && { opacity: 0.75 }]}
    >
      <IconChevronLeft />
    </Pressable>
  );
}

/** Centred title bar with the back button on the left and an optional action on the right. */
export function ScreenHeader({
  title,
  onBack,
  right,
}: {
  title: string;
  onBack?: () => void;
  right?: React.ReactNode;
}) {
  return (
    <View style={styles.header}>
      <View style={styles.headerSide}>{onBack ? <DarkBackButton onPress={onBack} /> : null}</View>
      <Text style={styles.headerTitle} numberOfLines={1}>
        {title}
      </Text>
      <View style={[styles.headerSide, { alignItems: 'flex-end' }]}>{right}</View>
    </View>
  );
}

/** Round corporate badge: first letters of the name in an orange ring. */
export function CorporateLogo({ name, size = 44 }: { name: string; size?: number }) {
  const letters =
    name
      .split(/\s+/)
      .filter(Boolean)
      .slice(0, 2)
      .map((w) => w[0]?.toUpperCase())
      .join('') || '•';
  return (
    <View style={[styles.logo, { width: size, height: size, borderRadius: size / 2 }]}>
      <Text style={[styles.logoText, { fontSize: size * 0.34 }]}>{letters}</Text>
    </View>
  );
}

export const NOTE_TEXT =
  'All start/end times are estimates and may start/conclude earlier/later, subjected to hotel’s discretion.';

function Dot() {
  return <Text style={styles.dot}>•</Text>;
}

/** "Male • Female • (2) Slots Left" row. */
export function SlotsRow({ job, chips = false }: { job: Job; chips?: boolean }) {
  const g = genders(job);
  const left = slotsLeft(job);
  if (chips) {
    return (
      <View style={styles.chipRow}>
        {g.male ? (
          <View style={styles.chip}>
            <IconUser size={16} color={colors.main} />
            <Text style={styles.chipText}>{g.female ? 'Male' : 'Male Only'}</Text>
          </View>
        ) : null}
        {g.female ? (
          <View style={styles.chip}>
            <IconUser size={16} color={colors.main} />
            <Text style={styles.chipText}>{g.male ? 'Female' : 'Female Only'}</Text>
          </View>
        ) : null}
        {left != null ? (
          <View style={styles.chip}>
            <View style={styles.slotCircleOrange}>
              <Text style={styles.slotCircleOrangeText}>{left}</Text>
            </View>
            <Text style={styles.chipText}>{left === 0 ? 'Fully booked' : 'Slots Left'}</Text>
          </View>
        ) : null}
      </View>
    );
  }
  return (
    <View style={styles.slotsRow}>
      {g.male && g.female ? (
        <>
          <IconUser size={15} />
          <Text style={styles.slotsText}>Male</Text>
          <Dot />
          <IconUser size={15} />
          <Text style={styles.slotsText}>Female</Text>
        </>
      ) : (
        <>
          <IconUser size={15} />
          <Text style={styles.slotsText}>{g.male ? 'Male Only' : 'Female Only'}</Text>
        </>
      )}
      {left != null ? (
        <>
          <Dot />
          <View style={styles.slotCircle}>
            <Text style={styles.slotCircleText}>{left}</Text>
          </View>
          <Text style={styles.slotsBold}>{left === 0 ? 'Fully booked' : 'Slots Left'}</Text>
        </>
      ) : null}
    </View>
  );
}

/** Calendar icon + "02 Feb 2026 • 6:00 PM to 12:00 AM". */
export function DateTimeLine({ job }: { job: Job }) {
  return (
    <View style={styles.dateLine}>
      <IconCalendarSmall size={16} />
      <Text style={styles.dateText}>{shortDate(job.eventDate)}</Text>
      <Dot />
      <Text style={styles.dateText}>{timeLabel(job.eventTime)}</Text>
    </View>
  );
}

/** Outline "View Detail ↗" button and the orange action button used on cards. */
export function CardButtons({
  onDetail,
  actionLabel,
  onAction,
  actionDisabled,
  actionTone = 'orange',
}: {
  onDetail: () => void;
  actionLabel?: string;
  onAction?: () => void;
  actionDisabled?: boolean;
  actionTone?: 'orange' | 'grey';
}) {
  return (
    <View style={styles.cardButtons}>
      <Pressable
        onPress={onDetail}
        accessibilityRole="button"
        style={({ pressed }) => [styles.detailBtn, pressed && { opacity: 0.7 }]}
      >
        <Text style={styles.detailText}>View Detail</Text>
        <IconArrowUpRight />
      </Pressable>
      {actionLabel ? (
        <Pressable
          onPress={onAction}
          disabled={actionDisabled}
          accessibilityRole="button"
          accessibilityState={{ disabled: !!actionDisabled }}
          style={({ pressed }) => [
            styles.actionBtn,
            actionTone === 'grey' && { backgroundColor: colors.stroke },
            pressed && !actionDisabled && { opacity: 0.85 },
          ]}
        >
          <Text style={[styles.actionText, actionTone === 'grey' && { color: colors.grey }]}>{actionLabel}</Text>
        </Pressable>
      ) : null}
    </View>
  );
}

/* ------------------------------------------------------------------ job card (Home / Search) */

export function JobCard({
  job,
  onDetail,
  actionLabel,
  onAction,
  actionDisabled,
}: {
  job: Job;
  onDetail: () => void;
  actionLabel: string;
  onAction: () => void;
  actionDisabled?: boolean;
}) {
  const rate = rateLabel(job.salary);
  return (
    <View style={styles.card}>
      <View style={styles.cardTop}>
        <CorporateLogo name={job.corporateName} />
        <View style={{ flex: 1, minWidth: 0 }}>
          <View style={styles.corpRow}>
            <Text style={styles.corpName} numberOfLines={1}>
              {job.corporateName}
            </Text>
            <Text style={styles.rate}>
              {rate.amount}
              <Text style={styles.rateUnit}>{rate.unit}</Text>
            </Text>
          </View>
          <View style={styles.addressRow}>
            <IconPin size={14} />
            <Text style={styles.address} numberOfLines={1}>
              {job.location || '—'}
            </Text>
          </View>
        </View>
      </View>
      <View style={styles.rule} />
      <Text style={styles.role} numberOfLines={1}>
        {job.title}
      </Text>
      <DateTimeLine job={job} />
      <View style={styles.rule} />
      <Text style={styles.note}>
        <Text style={styles.noteBold}>NOTE: </Text>
        {NOTE_TEXT}
      </Text>
      <SlotsRow job={job} />
      <CardButtons
        onDetail={onDetail}
        actionLabel={actionLabel}
        onAction={onAction}
        actionDisabled={actionDisabled}
        actionTone={actionDisabled ? 'grey' : 'orange'}
      />
    </View>
  );
}

/* ------------------------------------------------------------------ status badge */

const BADGE: Record<BookingState, { label: string; bg: string; fg: string }> = {
  pending: { label: 'Pending', bg: 'rgba(255,130,65,0.14)', fg: colors.main },
  confirmed: { label: 'Confirmed', bg: 'rgba(77,205,133,0.18)', fg: '#2E9E5E' },
  completed: { label: 'Completed', bg: 'rgba(77,205,133,0.18)', fg: '#2E9E5E' },
  cancelled: { label: 'Cancelled', bg: 'rgba(255,55,55,0.12)', fg: colors.error },
  job_cancelled: { label: 'Job Cancelled', bg: 'rgba(255,55,55,0.12)', fg: colors.error },
  rejected: { label: 'Rejected', bg: '#E4E4E4', fg: colors.grey },
};

export function StatusBadge({ state, style }: { state: BookingState; style?: StyleProp<ViewStyle> }) {
  const b = BADGE[state];
  return (
    <View style={[styles.badge, { backgroundColor: b.bg }, style]}>
      <Text style={[styles.badgeText, { color: b.fg }]}>{b.label}</Text>
    </View>
  );
}

/* ------------------------------------------------------------------ detail sections */

export function SectionTitle({ children, style }: { children: React.ReactNode; style?: StyleProp<ViewStyle> }) {
  return (
    <View style={style}>
      <Text style={styles.sectionTitle}>{children}</Text>
    </View>
  );
}

/** Three tiles: Event Date · Event Time · Rate (icon on top, centred). */
export function InfoTiles({ items }: { items: { icon: React.ReactNode; label: string; value: string }[] }) {
  return (
    <View style={styles.tiles}>
      {items.map((it) => (
        <View key={it.label} style={styles.tile}>
          {it.icon}
          <Text style={styles.tileLabel}>{it.label}</Text>
          <Text style={styles.tileValue}>{it.value}</Text>
        </View>
      ))}
    </View>
  );
}

/** Tiles with the label + value on the left and the icon on the right (Completed job). */
export function InfoTilesRow({ items }: { items: { icon: React.ReactNode; label: string; value: string }[] }) {
  return (
    <View style={styles.tilesWrap}>
      {items.map((it) => (
        <View key={it.label} style={styles.tileRow}>
          <View style={{ flex: 1 }}>
            <Text style={styles.tileRowLabel}>{it.label}</Text>
            <Text style={styles.tileRowValue}>{it.value}</Text>
          </View>
          {it.icon}
        </View>
      ))}
    </View>
  );
}

/** Description lines → bullets (a single paragraph stays a paragraph). */
export function AboutJob({ description }: { description: string }) {
  const lines = description
    .split(/\r?\n/)
    .map((l) => l.replace(/^\s*[-•*·]\s*/, '').trim())
    .filter(Boolean);
  return (
    <View>
      <SectionTitle>About the Job</SectionTitle>
      <Text style={styles.body}>
        <Text style={styles.noteBold}>NOTE: </Text>
        {NOTE_TEXT}
      </Text>
      {lines.length > 1 ? (
        <View style={{ marginTop: 8, gap: 2 }}>
          {lines.map((l, i) => (
            <View key={i} style={styles.bulletRow}>
              <Text style={styles.bullet}>•</Text>
              <Text style={[styles.body, { flex: 1 }]}>{l}</Text>
            </View>
          ))}
        </View>
      ) : lines.length === 1 ? (
        <Text style={[styles.body, { marginTop: 8 }]}>{lines[0]}</Text>
      ) : null}
    </View>
  );
}

export function Requirements({ items }: { items: string[] }) {
  if (items.length === 0) return null;
  return (
    <View>
      <SectionTitle>Requirements</SectionTitle>
      <View style={{ gap: 10, marginTop: 4 }}>
        {items.map((r, i) => (
          <View key={i} style={styles.reqRow}>
            <IconCheckCircle />
            <Text style={[styles.body, { flex: 1 }]}>{r}</Text>
          </View>
        ))}
      </View>
    </View>
  );
}

export function CancellationPolicy({ late = false }: { late?: boolean }) {
  return (
    <View style={styles.policy}>
      <IconWarning />
      <View style={{ flex: 1 }}>
        <Text style={styles.policyTitle}>Cancellation Policy</Text>
        <Text style={styles.policyText}>
          {late
            ? `As this job will start in less than 24 hours, cancelling this job now will incur a $${LATE_CANCEL_PENALTY} penalty.`
            : `Cancelling less than 24hours before the job starts will result in a $${LATE_CANCEL_PENALTY} penalty`}
        </Text>
      </View>
    </View>
  );
}

/** Map card with the address; tapping opens the phone's maps app. */
export function EventLocation({ address }: { address: string }) {
  const { width } = useWindowDimensions();
  const open = () => {
    if (!address) return;
    void Linking.openURL(`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(address)}`);
  };
  return (
    <View>
      <SectionTitle>Event Location</SectionTitle>
      <Pressable
        onPress={open}
        accessibilityRole="link"
        accessibilityLabel={`Open ${address} in maps`}
        style={({ pressed }) => [styles.mapCard, pressed && { opacity: 0.9 }]}
      >
        <View style={styles.map}>
          <MapIllustration width={width - 40} height={190} />
        </View>
        <View style={styles.mapAddress}>
          <IconNavigate />
          <Text style={styles.mapAddressText}>{address || 'Address not provided'}</Text>
        </View>
      </Pressable>
    </View>
  );
}

/** "Payment Method: Bank Transfer   $" strip. */
export function PaymentMethodRow({ method, icon }: { method: string; icon: React.ReactNode }) {
  return (
    <View style={styles.payRow}>
      <Text style={styles.payLabel}>
        Payment Method: <Text style={styles.payValue}>{method}</Text>
      </Text>
      {icon}
    </View>
  );
}

export const jobStyles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.white },
});

const styles = StyleSheet.create({
  back: {
    width: 32,
    height: 32,
    borderRadius: 8,
    backgroundColor: colors.dark,
    alignItems: 'center',
    justifyContent: 'center',
  },
  header: { flexDirection: 'row', alignItems: 'center', minHeight: 44, paddingHorizontal: 20 },
  headerSide: { width: 44 },
  headerTitle: {
    flex: 1,
    textAlign: 'center',
    fontFamily: fonts.semibold,
    fontSize: 20,
    lineHeight: 28,
    color: colors.text,
  },
  logo: {
    borderWidth: 1.5,
    borderColor: colors.main,
    backgroundColor: colors.white,
    alignItems: 'center',
    justifyContent: 'center',
  },
  logoText: { fontFamily: fonts.bold, color: colors.main },
  dot: { fontFamily: fonts.regular, fontSize: 12, color: colors.grey, marginHorizontal: 6 },

  card: { backgroundColor: colors.greyBg, borderRadius: 20, padding: 20 },
  cardTop: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  corpRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 8 },
  corpName: { flex: 1, fontFamily: fonts.semibold, fontSize: 16, lineHeight: 22, color: colors.text },
  rate: { fontFamily: fonts.bold, fontSize: 14, lineHeight: 20, color: colors.text },
  rateUnit: { fontFamily: fonts.regular },
  addressRow: { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 4 },
  address: { flex: 1, fontFamily: fonts.regular, fontSize: 12, lineHeight: 16, color: colors.grey },
  rule: { height: 1, backgroundColor: colors.stroke, marginVertical: 12 },
  role: { fontFamily: fonts.semibold, fontSize: 14, lineHeight: 20, color: colors.text, marginBottom: 6 },
  dateLine: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  dateText: { fontFamily: fonts.regular, fontSize: 12, lineHeight: 16, color: colors.grey },
  note: { fontFamily: fonts.regular, fontSize: 14, lineHeight: 22, color: colors.grey },
  noteBold: { fontFamily: fonts.bold, color: colors.dark },
  slotsRow: { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 12, flexWrap: 'wrap' },
  slotsText: { fontFamily: fonts.regular, fontSize: 12, color: colors.text },
  slotsBold: { fontFamily: fonts.semibold, fontSize: 12, color: colors.text },
  slotCircle: {
    width: 22,
    height: 22,
    borderRadius: 11,
    backgroundColor: colors.stroke,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 2,
  },
  slotCircleText: { fontFamily: fonts.semibold, fontSize: 12, color: colors.text },
  cardButtons: { flexDirection: 'row', gap: 20, marginTop: 14 },
  detailBtn: {
    flex: 1,
    height: 40,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: colors.text,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
  },
  detailText: { fontFamily: fonts.medium, fontSize: 16, color: colors.text },
  actionBtn: {
    flex: 1,
    height: 40,
    borderRadius: 8,
    backgroundColor: colors.main,
    alignItems: 'center',
    justifyContent: 'center',
  },
  actionText: { fontFamily: fonts.medium, fontSize: 16, color: colors.white },

  badge: { paddingHorizontal: 10, paddingVertical: 3, borderRadius: 999 },
  badgeText: { fontFamily: fonts.medium, fontSize: 11, lineHeight: 15 },

  chipRow: { flexDirection: 'row', gap: 8, flexWrap: 'wrap' },
  chip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: colors.mainTint,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 999,
  },
  chipText: { fontFamily: fonts.medium, fontSize: 14, color: colors.text },
  slotCircleOrange: {
    width: 20,
    height: 20,
    borderRadius: 10,
    borderWidth: 1.2,
    borderColor: colors.main,
    alignItems: 'center',
    justifyContent: 'center',
  },
  slotCircleOrangeText: { fontFamily: fonts.medium, fontSize: 11, color: colors.main },

  sectionTitle: { fontFamily: fonts.semibold, fontSize: 20, lineHeight: 28, color: colors.text, marginBottom: 8 },
  tiles: { flexDirection: 'row', gap: 10 },
  tile: {
    flex: 1,
    backgroundColor: colors.greyBg,
    borderRadius: 14,
    paddingVertical: 16,
    paddingHorizontal: 6,
    alignItems: 'center',
    gap: 8,
  },
  tileLabel: { fontFamily: fonts.regular, fontSize: 12, color: colors.grey, marginTop: 4 },
  tileValue: { fontFamily: fonts.semibold, fontSize: 12, color: colors.text, textAlign: 'center' },
  tilesWrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 12 },
  tileRow: {
    width: '47.8%',
    flexGrow: 1,
    backgroundColor: colors.greyBg,
    borderRadius: 14,
    padding: 14,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  tileRowLabel: { fontFamily: fonts.regular, fontSize: 12, color: colors.grey },
  tileRowValue: { fontFamily: fonts.semibold, fontSize: 13, color: colors.text, marginTop: 6 },

  body: { fontFamily: fonts.regular, fontSize: 14, lineHeight: 22, color: colors.grey },
  bulletRow: { flexDirection: 'row', gap: 8, paddingLeft: 6 },
  bullet: { fontFamily: fonts.regular, fontSize: 14, lineHeight: 22, color: colors.grey },
  reqRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },

  policy: {
    flexDirection: 'row',
    gap: 12,
    backgroundColor: colors.errorBg,
    borderRadius: 12,
    padding: 16,
    alignItems: 'flex-start',
  },
  policyTitle: { fontFamily: fonts.semibold, fontSize: 14, color: colors.error },
  policyText: { fontFamily: fonts.regular, fontSize: 12, lineHeight: 18, color: colors.error, marginTop: 2 },

  mapCard: { borderRadius: 20, overflow: 'hidden', backgroundColor: colors.greyBg },
  map: { height: 190, overflow: 'hidden' },
  mapAddress: { flexDirection: 'row', alignItems: 'center', gap: 12, padding: 16 },
  mapAddressText: { flex: 1, fontFamily: fonts.medium, fontSize: 14, lineHeight: 20, color: colors.text },

  payRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: colors.greyBg,
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 12,
  },
  payLabel: { fontFamily: fonts.regular, fontSize: 12, color: colors.grey },
  payValue: { fontFamily: fonts.semibold, color: colors.text },
});
